package com.examly.springapp.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;

@Entity
public class Student{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min =3, max =50)
    private String name;

    @NotBlank
    @Email
    private String email;

    @NotBlank
    @Size(min = 5, max = 10)
    @Column(unique = true)
    private String rollNumber;

    @NotBlank
    private String grade;

    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}
    public String getName(){return name;}
    public void setName(String name){this.name = name;}
    public String getEmail(){return email;}
    public void setEmail(String email){this.email = email;}
    public String getRollNumber(){return rollNumber;}
    public void setRollNumber(String rollNumber){this.rollNumber= rollNumber;};
    public String getGrade(){return grade;}
    public void setGrade(String grade){this.grade = grade;}
    public Student(@NotBlank @Size(min = 3, max = 50) String name, @NotBlank @Email String email,
            @NotBlank @Size(min = 5, max = 10) String rollNumber, @NotBlank String grade) {
        this.name = name;
        this.email = email;
        this.rollNumber = rollNumber;
        this.grade = grade;
    }
    public Student() {
    }
    

}

