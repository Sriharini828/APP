package com.examly.springapp.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Score;
import com.examly.springapp.model.Student;
import com.examly.springapp.model.Subject;
import com.examly.springapp.repository.ScoreRepository;
import com.examly.springapp.repository.StudentRepository;
import com.examly.springapp.repository.SubjectRepository;

@Service
public class ScoreService {
    @Autowired
    private ScoreRepository scoreRepo;

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private SubjectRepository subjectRepo;

    // public Score save(Score s){
    //     return scoreRepo.save(s);
    // }

    // public List<Score> getByStudentId(Long studentId){
    //     return scoreRepo.findByStudentId(studentId);
    // }

    // public List<Score> getByFilters(Long studentId, Long subjectId,String examType, LocalDate startDate, LocalDate endDate){
    //     if(subjectId != null && examType != null){
    //         return scoreRepo.findByStudentIdAndSubjectIdAndExamType(studentId,subjectId,examType);
    //     }
    //     if(subjectId != null && startDate != null && endDate != null){
    //         return scoreRepo.findByStudentIdAndSubjectIdAndExamDateBetween(studentId,subjectId,startDate,endDate);
    //     }
    //     if(subjectId != null){
    //         return scoreRepo.findByStudentIdAndSubjectId(studentId,subjectId);
    //     }
    //     return scoreRepo.findByStudentId(studentId);
    // }

    public Score createScore(Score score, Long studentId, Long subjectId){
        if(score.getExamDate().isAfter(LocalDate.now())){
            throw new IllegalArgumentException("Exam date cannot be a future date");
        }
        Student student = studentRepo.findById(studentId).orElseThrow(()->new IllegalArgumentException("Student not found"));
        Subject subject = subjectRepo.findById(subjectId).orElseThrow(()-> new IllegalArgumentException("Subject not found"));
        score.setStudent(student);
        score.setSubject(subject);
        return scoreRepo.save(score);
    }

    public Score createScore(Score score){
        if(score.getStudent() == null|| score.getSubject() == null){
            throw new IllegalArgumentException("Student and subject must be provided");
        }
        return createScore(score, score.getStudent().getId(), score.getSubject().getId());
    }

    // public Score createScore(Score score, long studentId, long subjectId){
    //     return scoreRepo.save(score);
    // }

        // public Score createScore(Score s){
        //     return scoreRepo.save(s);
        // }

    public List<Score> getScoresByStudent(long studentId, Object o1, Object o2, Object o3, Object o4){
        if(!studentRepo.existsById(studentId)){
            throw new IllegalArgumentException("Student not found");
        }
        return scoreRepo.findByStudentId(studentId);
    }

    public List<Score> getPerformanceTrend(long studentId, long subjectId){
        if(!studentRepo.existsById(studentId)){
            throw new IllegalArgumentException("Student not found");
        }
        if(!subjectRepo.existsById(subjectId)){
            throw new IllegalArgumentException("Subject not found");
        }
        return scoreRepo.findByStudentIdAndSubjectId(studentId, subjectId);
    }
}
        
    

