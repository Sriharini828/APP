package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examly.springapp.model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByGrade(String grade);

    
} 