package com.examly.springapp.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Score;
import com.examly.springapp.service.ScoreService;
import com.examly.springapp.service.StudentService;
import com.examly.springapp.service.SubjectService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/scores")
public class ScoreController {
    @Autowired
    private ScoreService scoreService;

    @PostMapping
    public ResponseEntity<?> recordScore(@Valid @RequestBody Score score, @RequestParam Long studentId, @RequestParam Long subjectId){
        try{
            Score created  = scoreService.createScore(score, studentId, subjectId);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        }
        catch(IllegalArgumentException ex){
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // @PostMapping
    // public ResponseEntity<?> recordScore(@Valid @RequestBody Score score){
    //     Long studentId = score.getStudent().getId();
    //     Long subjectid = score.getSubject().getId();
    //     if(!studentService.getById(studentId).isPresent() || subjectService.getAll().stream().noneMatch(s -> s.getId().equals(subjectid) )){
    //         return new ResponseEntity<>("Student or Subject not found", HttpStatus.BAD_REQUEST);
    //     }
    //     if(score.getExamDate().isAfter(LocalDate.now())){
    //         return new ResponseEntity<>("Exam date cannot be a future date.", HttpStatus.BAD_REQUEST);
    //     }
    //     Score created  = scoreService.save(score);
    //     return new ResponseEntity<>(created, HttpStatus.CREATED);
    // }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getScoresByStudent(@PathVariable Long studentId){
        try{
            List<Score> scores = scoreService.getScoresByStudent(studentId, null, null, null, null);
            return ResponseEntity.ok(scores);
        }
        catch(IllegalArgumentException ex){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(java.util.Collections.singletonMap("message",ex.getMessage()));
        }
        
    }

    @GetMapping("/trend/student/{studentId}/subject/{subjectId}")
    public ResponseEntity<?> getPerformanceTrend(@PathVariable Long studentId, @PathVariable Long subjectId){
        try{
            List<Score> scores = scoreService.getPerformanceTrend(studentId,subjectId);
            return ResponseEntity.ok(scores);
        }
        catch(IllegalArgumentException ex){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(java.util.Collections.singletonMap("message",ex.getMessage()));
        }
    }
    
}
