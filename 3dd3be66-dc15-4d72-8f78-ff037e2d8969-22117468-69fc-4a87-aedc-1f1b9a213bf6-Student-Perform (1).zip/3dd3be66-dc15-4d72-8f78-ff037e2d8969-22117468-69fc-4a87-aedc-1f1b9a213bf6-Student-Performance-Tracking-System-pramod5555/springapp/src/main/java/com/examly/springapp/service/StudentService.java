package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Student;
import com.examly.springapp.repository.StudentRepository;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepo;

    

    // public List<Student> getAll(String grade){
    //     if(grade == null) return studentRepo.findAll();
    //     return studentRepo.findByGrade(grade);
    // }

    // public Optional<Student> getById(Long id){
    //     return studentRepo.findById(id);
    // }
    public Student createStudent(Student student){
        if(studentRepo.findAll().stream().anyMatch(s -> s.getRollNumber().equals(student.getRollNumber()))){
            throw new IllegalArgumentException("Student with this roll number already exists");
        }
        
        return studentRepo.save(student);
    }
    

    public Student getStudentById(Long id){
        return studentRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Student not found"));
    }

    public List<Student> getAllStudents(String grade){
        if(grade == null){
            return studentRepo.findAll();
        }
        else{
            return studentRepo.findByGrade(grade);
        }
    }
}
