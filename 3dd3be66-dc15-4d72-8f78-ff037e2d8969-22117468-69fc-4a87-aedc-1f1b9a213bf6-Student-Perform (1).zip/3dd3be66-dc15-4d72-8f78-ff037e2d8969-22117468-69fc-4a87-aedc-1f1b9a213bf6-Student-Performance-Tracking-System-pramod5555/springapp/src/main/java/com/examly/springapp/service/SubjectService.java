package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Subject;
import com.examly.springapp.repository.SubjectRepository;

@Service
public class SubjectService {
    @Autowired
    private SubjectRepository subjectRepo;

    // public Subject save(Subject s){
    //     return subjectRepo.save(s);
    // }

    // public List<Subject> getAll(){
    //     return subjectRepo.findAll();
    // }

    public Subject createSubject(Subject subject){
        try{
            return subjectRepo.save(subject);
        }
        catch(DataIntegrityViolationException ex){
            throw new IllegalArgumentException("Subject with this code already exists.");
        }
    }

   

    public Subject getSubjectById(Long id){
        return subjectRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Subject not found"));
    }
    public List<Subject> getAllSubjects(){
        return subjectRepo.findAll();
    }




}
