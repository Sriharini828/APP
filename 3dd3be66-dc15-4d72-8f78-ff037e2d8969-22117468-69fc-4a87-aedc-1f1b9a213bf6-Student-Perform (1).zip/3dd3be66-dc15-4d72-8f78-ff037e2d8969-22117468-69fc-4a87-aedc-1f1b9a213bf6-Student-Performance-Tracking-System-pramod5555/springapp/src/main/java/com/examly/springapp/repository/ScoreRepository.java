package com.examly.springapp.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examly.springapp.model.Score;

public interface ScoreRepository extends JpaRepository<Score,Long>{
    List<Score> findByStudentId(Long studentId);
    List<Score> findByStudentIdAndSubjectId(Long studentId, Long subjectId);
    List<Score> findByStudentIdAndSubjectIdAndExamType(Long studentId, Long subjectId, String examType);
    List<Score> findByStudentIdAndSubjectIdAndExamDateBetween(Long studentId, Long subjectId, LocalDate startDate,LocalDate endDate);

    
}
