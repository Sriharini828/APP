package com.examly.springapp.service;

import com.examly.springapp.model.Student;
import com.examly.springapp.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StudentServiceTest {
    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createStudent_valid() {
        Student student = new Student("Test User", "test@test.com", "S67890", "10th");
        when(studentRepository.save(student)).thenReturn(student);
        Student created = studentService.createStudent(student);
        assertEquals(student.getName(), created.getName());
    }

    @Test
    void createStudent_duplicateRollNumber() {
        Student student = new Student("Test User", "test@test.com", "S67890", "10th");
        when(studentRepository.save(student)).thenThrow(new org.springframework.dao.DataIntegrityViolationException("Duplicate"));
        Exception ex = assertThrows(IllegalArgumentException.class, () -> studentService.createStudent(student));
        assertEquals("Student with this roll number already exists.", ex.getMessage());
    }

    @Test
    void getStudentById_found() {
        Student student = new Student("Test User", "test@test.com", "S67891", "11th");
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        Student result = studentService.getStudentById(1L);
        assertEquals("S67891", result.getRollNumber());
    }

    @Test
    void getStudentById_notFound() {
        when(studentRepository.findById(100L)).thenReturn(Optional.empty());
        Exception ex = assertThrows(IllegalArgumentException.class, () -> studentService.getStudentById(100L));
        assertEquals("Student not found", ex.getMessage());
    }

    @Test
    void getAllStudents_byGrade() {
        Student s1 = new Student("A One", "a@one.com", "S10000", "10th");
        Student s2 = new Student("B Two", "b@two.com", "S10001", "10th");
        when(studentRepository.findByGrade("10th")).thenReturn(List.of(s1, s2));
        List<Student> students = studentService.getAllStudents("10th");
        assertEquals(2, students.size());
    }
}
