package com.examly.springapp.controller;

import com.examly.springapp.model.Score;
import com.examly.springapp.service.ScoreService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.time.LocalDate;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@WebMvcTest(ScoreController.class)
class ScoreControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private ScoreService scoreService;

    @Test
    void testGetScoresByStudent_success() throws Exception {
        Score score = new Score();
        score.setId(1L);
        score.setValue(85);
        score.setExamDate(LocalDate.parse("2023-10-15"));
        score.setExamType("Quiz");
        when(scoreService.getScoresByStudent(eq(1L), any(), any(), any(), any())).thenReturn(List.of(score));
        mockMvc.perform(get("/api/scores/student/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].value", is(85)))
                .andExpect(jsonPath("$[0].examDate", is("2023-10-15")));
    }

    @Test
    void testGetScoresByStudent_notFound() throws Exception {
        when(scoreService.getScoresByStudent(eq(99L), any(), any(), any(), any()))
            .thenThrow(new IllegalArgumentException("Student not found"));
        mockMvc.perform(get("/api/scores/student/99"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.message", is("Student not found")));
    }

    @Test
    void testGetPerformanceTrend_success() throws Exception {
        Score score = new Score();
        score.setId(1L);
        score.setValue(90);
        score.setExamDate(LocalDate.parse("2023-10-20"));
        score.setExamType("Midterm");
        when(scoreService.getPerformanceTrend(1L, 2L)).thenReturn(List.of(score));
        mockMvc.perform(get("/api/scores/trend/student/1/subject/2"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].value", is(90)));
    }

    @Test
    void testGetPerformanceTrend_notFound() throws Exception {
        when(scoreService.getPerformanceTrend(777L, 888L)).thenThrow(new IllegalArgumentException("Student not found"));
        mockMvc.perform(get("/api/scores/trend/student/777/subject/888"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.message", is("Student not found")));
    }
}
