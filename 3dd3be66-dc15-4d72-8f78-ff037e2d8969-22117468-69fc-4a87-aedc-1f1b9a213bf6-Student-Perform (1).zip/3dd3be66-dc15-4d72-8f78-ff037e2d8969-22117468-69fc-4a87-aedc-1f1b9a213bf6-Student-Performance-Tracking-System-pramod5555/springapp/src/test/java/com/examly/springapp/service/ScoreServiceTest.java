package com.examly.springapp.service;

import com.examly.springapp.model.Score;
import com.examly.springapp.model.Student;
import com.examly.springapp.model.Subject;
import com.examly.springapp.repository.ScoreRepository;
import com.examly.springapp.repository.StudentRepository;
import com.examly.springapp.repository.SubjectRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ScoreServiceTest {
    @Mock
    private ScoreRepository scoreRepository;
    @Mock
    private StudentRepository studentRepository;
    @Mock
    private SubjectRepository subjectRepository;
    @InjectMocks
    private ScoreService scoreService;

    private Student student;
    private Subject subject;
    private Score score;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        student = new Student("Student Test", "mail@mail.com", "S11223", "10th");
        student.setId(1L);
        subject = new Subject("Math", "M1");
        subject.setId(2L);
        score = new Score(student, subject, 95, LocalDate.now().minusDays(1), "Midterm");
        score.setId(5L);
    }

    @Test
    void createScore_valid() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        when(subjectRepository.findById(2L)).thenReturn(Optional.of(subject));
        when(scoreRepository.save(any(Score.class))).thenReturn(score);
        Score created = scoreService.createScore(score, 1L, 2L);
        assertEquals(95, created.getValue());
    }

    @Test
    void createScore_futureDate() {
        score.setExamDate(LocalDate.now().plusDays(2));
        Exception ex = assertThrows(IllegalArgumentException.class, () -> scoreService.createScore(score, 1L, 2L));
        assertEquals("Exam date cannot be a future date", ex.getMessage());
    }

    @Test
    void createScore_missingStudent() {
        when(studentRepository.findById(1L)).thenReturn(Optional.empty());
        Exception ex = assertThrows(IllegalArgumentException.class, () -> scoreService.createScore(score, 1L, 2L));
        assertEquals("Student not found", ex.getMessage());
    }

    @Test
    void createScore_missingSubject() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        when(subjectRepository.findById(2L)).thenReturn(Optional.empty());
        Exception ex = assertThrows(IllegalArgumentException.class, () -> scoreService.createScore(score, 1L, 2L));
        assertEquals("Subject not found", ex.getMessage());
    }
}
