package com.examly.springapp.service;

import com.examly.springapp.model.Subject;
import com.examly.springapp.repository.SubjectRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SubjectServiceTest {
    @Mock
    private SubjectRepository subjectRepository;
    @InjectMocks
    private SubjectService subjectService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createSubject_valid() {
        Subject subject = new Subject("Mathematics", "MATH101");
        when(subjectRepository.save(subject)).thenReturn(subject);
        Subject created = subjectService.createSubject(subject);
        assertEquals("Mathematics", created.getName());
    }

    @Test
    void createSubject_duplicateCode() {
        Subject subject = new Subject("Mathematics", "MATH101");
        when(subjectRepository.save(subject)).thenThrow(new org.springframework.dao.DataIntegrityViolationException("Duplicate"));
        Exception ex = assertThrows(IllegalArgumentException.class, () -> subjectService.createSubject(subject));
        assertEquals("Subject with this code already exists.", ex.getMessage());
    }

    @Test
    void getAllSubjects() {
        Subject s1 = new Subject("Math", "MATH101");
        Subject s2 = new Subject("Sci", "SCI100");
        when(subjectRepository.findAll()).thenReturn(List.of(s1, s2));
        List<Subject> list = subjectService.getAllSubjects();
        assertEquals(2, list.size());
    }

    @Test
    void getSubjectById_found() {
        Subject s = new Subject("Eng", "ENG100");
        when(subjectRepository.findById(1L)).thenReturn(Optional.of(s));
        Subject found = subjectService.getSubjectById(1L);
        assertEquals("Eng", found.getName());
    }

    @Test
    void getSubjectById_notFound() {
        when(subjectRepository.findById(5L)).thenReturn(Optional.empty());
        Exception ex = assertThrows(IllegalArgumentException.class, () -> subjectService.getSubjectById(5L));
        assertEquals("Subject not found", ex.getMessage());
    }
}
