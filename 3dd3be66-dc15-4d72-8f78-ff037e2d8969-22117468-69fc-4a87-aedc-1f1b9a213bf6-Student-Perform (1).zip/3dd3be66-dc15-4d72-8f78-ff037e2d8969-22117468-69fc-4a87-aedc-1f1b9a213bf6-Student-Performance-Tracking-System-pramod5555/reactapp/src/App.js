import React from 'react';
import { BrowserRouter as Router, Routes, Route, useParams } from 'react-router-dom';
import NavigationBar from './components/NavigationBar';
import Dashboard from './components/Dashboard';
import StudentForm from './components/StudentForm';
import StudentList from './components/StudentList';
import SubjectList from './components/SubjectList';
import SubjectForm from './components/SubjectForm';
import ScoreForm from './components/ScoreForm';
import StudentScores from './components/StudentScores';
import PerformanceChart from './components/PerformanceChart';
import './App.css';

function PerformanceChartWrapper() {
    const { studentId } = useParams();
    return <PerformanceChart studentId={studentId} />;
}

function StudentScoresWrapper() {
    const { studentId } = useParams();
    return <StudentScores studentId={studentId} />;
}

export default function App() {
    // Summary stats demo; ideally fetch from backend
    const dashboardStats = { students: 120, scores: 450, subjects: 8 };
    return (
        <Router>
            <NavigationBar />
            <main className="main-content">
                <Routes>
                    <Route path="/" element={<Dashboard stats={dashboardStats} />} />
                    <Route path="/students" element={<><StudentForm /><StudentList /></>} />
                    <Route path="/subjects" element={<><SubjectForm /><SubjectList /></>} />
                    <Route path="/scores" element={<ScoreForm />} />
                    <Route path="/performance/:studentId" element={<PerformanceChartWrapper />} />
                    <Route path="/scores/:studentId" element={<StudentScoresWrapper />} />
                </Routes>
            </main>
        </Router>
    );
}
