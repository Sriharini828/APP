import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import StudentList from '../components/StudentList';
import { BrowserRouter } from 'react-router-dom';

global.fetch = jest.fn();
const renderComp = () => render(<BrowserRouter><StudentList /></BrowserRouter>);

describe('StudentList', () => {
  beforeEach(() => {
    fetch.mockClear();
  });
  it('renders and filters students', async () => {
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ([
        { id: 11, name: 'Alice', rollNumber: 'R001', grade: '10th' },
        { id: 12, name: 'Bob', rollNumber: 'R002', grade: '11th' }
      ])
    });
    renderComp();
    expect(await screen.findByText('Alice')).toBeInTheDocument();
    expect(screen.getByText('Bob')).toBeInTheDocument();
    // Filter
    fireEvent.change(screen.getByTestId('grade-filter'), { target: { value: '10th' } });
    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.queryByText('Bob')).not.toBeInTheDocument();
  });

  it('shows empty state', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [] });
    renderComp();
    expect(await screen.findByText(/No students/)).toBeInTheDocument();
  });

  it('handles errors', async () => {
    fetch.mockRejectedValueOnce({ response: { data: { message: 'API failed' } } });
    renderComp();
    expect(await screen.findByText('API failed')).toBeInTheDocument();
  });
  
  it('navigates to performance page', async () => {
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ([{ id: 20, name: 'Eve', rollNumber: 'E123', grade: '12th' }])
    });
    renderComp();
    expect(await screen.findByText('Eve')).toBeInTheDocument();
    const btn = screen.getByText('View Performance');
    expect(btn).toBeInTheDocument();
  });
});
