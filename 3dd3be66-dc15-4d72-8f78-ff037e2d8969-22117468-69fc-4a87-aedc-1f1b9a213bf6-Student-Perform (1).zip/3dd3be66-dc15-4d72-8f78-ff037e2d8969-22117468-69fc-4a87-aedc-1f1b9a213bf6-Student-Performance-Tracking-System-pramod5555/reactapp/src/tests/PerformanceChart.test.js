import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PerformanceChart from '../components/PerformanceChart';

global.fetch = jest.fn();

describe('PerformanceChart', () => {
  beforeEach(() => { fetch.mockClear(); });

  
  it('renders the chart on data', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 10, name: 'Math' }] }); // subjects
    render(<PerformanceChart studentId={44} />);
    expect(await screen.findByText('Performance Trend')).toBeInTheDocument();
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [
      { value: 90, examDate: '2023-01-10' },
      { value: 80, examDate: '2023-02-10' }
    ] }); // trend data
    fireEvent.change(screen.getByTestId('subject-picker'), { target: { value: '10' } });
    // Wait for both labels to appear
    const label1 = await screen.findByTestId('exam-label-2023-01-10', {}, { timeout: 1600 });
    const label2 = await screen.findByTestId('exam-label-2023-02-10', {}, { timeout: 1600 });
    expect(label1).toBeInTheDocument();
    expect(label2).toBeInTheDocument();
    expect(screen.getByText('100')).toBeInTheDocument();
    expect(screen.getByText('0')).toBeInTheDocument();
    expect(screen.getByText('50')).toBeInTheDocument();
  });

  it('shows error if API fails', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: '1', name: 'Chem' }] }); // subjects
    render(<PerformanceChart studentId={3} />);
    fetch.mockRejectedValueOnce({ response: { data: { message: 'API Err' } } });
    fireEvent.change(screen.getByTestId('subject-picker'), { target: { value: '1' } });
    const errorDiv = await screen.findByTestId('err-div', {}, { timeout: 1600 });
    expect(errorDiv).toBeInTheDocument();
  });
});
