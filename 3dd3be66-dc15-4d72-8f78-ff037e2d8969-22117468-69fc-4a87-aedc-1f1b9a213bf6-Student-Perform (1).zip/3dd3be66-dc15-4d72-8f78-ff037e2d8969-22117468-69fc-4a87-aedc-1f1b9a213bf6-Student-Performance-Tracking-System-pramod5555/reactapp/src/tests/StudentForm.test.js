import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import StudentForm from '../components/StudentForm';

global.fetch = jest.fn();

beforeEach(() => { fetch.mockClear(); });

describe('StudentForm', () => {
  it('shows validation errors and disables submit', () => {
    render(<StudentForm />);
    fireEvent.change(screen.getByTestId('name-input'), { target: { value: '' } });
    fireEvent.change(screen.getByTestId('email-input'), { target: { value: 'bademail...' } });
    fireEvent.change(screen.getByTestId('rollNumber-input'), { target: { value: '123' } });
    fireEvent.change(screen.getByTestId('grade-input'), { target: { value: '' } });
    fireEvent.click(screen.getByTestId('submit-button'));
    expect(screen.getByText(/Name must be/)).toBeInTheDocument();
    expect(screen.getByText(/Email should/)).toBeInTheDocument();
    expect(screen.getByText(/Roll number/)).toBeInTheDocument();
    expect(screen.getByText(/Grade is required/)).toBeInTheDocument();
    expect(screen.getByTestId('submit-button')).toBeDisabled();
  });

  it('submits successfully', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => ({}) });
    render(<StudentForm />);
    fireEvent.change(screen.getByTestId('name-input'), { target: { value: 'Student User' } });
    fireEvent.change(screen.getByTestId('email-input'), { target: { value: 'user@mail.com' } });
    fireEvent.change(screen.getByTestId('rollNumber-input'), { target: { value: 'S11111' } });
    fireEvent.change(screen.getByTestId('grade-input'), { target: { value: '10th' } });
    fireEvent.click(screen.getByTestId('submit-button'));
    expect(await screen.findByText('Student added successfully')).toBeInTheDocument();
  });

  it('shows backend error when duplicate', async () => {
    fetch.mockRejectedValueOnce({ response: { data: { message: 'Student with this roll number already exists.' } } });
    render(<StudentForm />);
    fireEvent.change(screen.getByTestId('name-input'), { target: { value: 'Test' } });
    fireEvent.change(screen.getByTestId('email-input'), { target: { value: 't@t.com' } });
    fireEvent.change(screen.getByTestId('rollNumber-input'), { target: { value: 'S20000' } });
    fireEvent.change(screen.getByTestId('grade-input'), { target: { value: '10th' } });
    fireEvent.click(screen.getByTestId('submit-button'));
    expect(await screen.findByText(/already exists/)).toBeInTheDocument();
  });
});
