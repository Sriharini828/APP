import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import StudentScores from '../components/StudentScores';

global.fetch = jest.fn();

describe('StudentScores', () => {
  beforeEach(() => { fetch.mockClear(); });
  it('renders and filters scores', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 1, name: 'Math' }] }); // subjects
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [
      { id: 11, value: 88, examDate: '2023-01-01', examType: 'Quiz', subject: { id: 1 } }
    ] }); // scores
    render(<StudentScores studentId={16} />);
    // Ensure subject and row exist
    expect(await screen.findByTestId('score-row-11')).toBeInTheDocument();
    expect(screen.getByTestId('score-row-11')).toHaveTextContent('88');
    expect(screen.getByTestId('score-row-11')).toHaveTextContent('Quiz');
    // Provide for the filter-triggered fetch as well:
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [
      { id: 11, value: 88, examDate: '2023-01-01', examType: 'Quiz', subject: { id: 1 } }
    ] }); // filtered scores (same)
    fireEvent.change(screen.getByTestId('subject-filter'), { target: { value: '1' } });
    expect(await screen.findByTestId('score-row-11')).toBeInTheDocument();
  });

  it('shows empty state', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 1, name: 'Math' }] }); // subjects
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [] }); // scores
    render(<StudentScores studentId={77} />);
    expect(await screen.findByText('No scores found.')).toBeInTheDocument();
  });

  it('shows error message', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 1, name: 'Math' }] }); // subjects
    fetch.mockRejectedValueOnce({ response: { data: { message: 'Not found' } } });
    render(<StudentScores studentId={99} />);
    expect(await screen.findByText('Not found')).toBeInTheDocument();
  });
});
