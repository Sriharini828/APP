import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import ScoreForm from '../components/ScoreForm';

global.fetch = jest.fn();

beforeEach(() => { fetch.mockClear(); });

describe('ScoreForm', () => {
  it('validates required fields', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [] });
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [] });
    render(<ScoreForm />);
    fireEvent.click(screen.getByTestId('submit-score'));
    expect(screen.getByText(/Student is required/)).toBeInTheDocument();
    expect(screen.getByText(/Subject is required/)).toBeInTheDocument();
    expect(screen.getByText(/Score must be 0-100/)).toBeInTheDocument();
    expect(screen.getByText(/Exam date required/)).toBeInTheDocument();
    expect(screen.getByText(/Exam type required/)).toBeInTheDocument();
    expect(screen.getByTestId('submit-score')).toBeDisabled();
  });
  it('submits successfully', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 1, name: "A" }] }); // students
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 2, name: "S" }] }); // subjects
    fetch.mockResolvedValueOnce({ ok: true, json: async () => ({}) }); // post
    render(<ScoreForm />);
    fireEvent.change(screen.getByTestId('student-select'), { target: { value: '1' } });
    fireEvent.change(screen.getByTestId('subject-select'), { target: { value: '2' } });
    fireEvent.change(screen.getByTestId('score-value'), { target: { value: '90' } });
    fireEvent.change(screen.getByTestId('exam-date'), { target: { value: '2023-09-09' } });
    fireEvent.change(screen.getByTestId('exam-type-select'), { target: { value: 'Quiz' } });
    fireEvent.click(screen.getByTestId('submit-score'));
    await waitFor(() => {
      expect(screen.getByTestId('score-success-message')).toHaveTextContent(/Score recorded/);
    }, {timeout: 2000});
  });
  it('shows backend error', async () => {
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 1, name: "A" }] });
    fetch.mockResolvedValueOnce({ ok: true, json: async () => [{ id: 2, name: "S" }] });
    fetch.mockRejectedValueOnce({ response: { data: { message: 'Error occurred' } } });
    render(<ScoreForm />);
    fireEvent.change(screen.getByTestId('student-select'), { target: { value: '1' } });
    fireEvent.change(screen.getByTestId('subject-select'), { target: { value: '2' } });
    fireEvent.change(screen.getByTestId('score-value'), { target: { value: '90' } });
    fireEvent.change(screen.getByTestId('exam-date'), { target: { value: '2023-09-09' } });
    fireEvent.change(screen.getByTestId('exam-type-select'), { target: { value: 'Quiz' } });
    fireEvent.click(screen.getByTestId('submit-score'));
    await waitFor(() => {
      expect(screen.getByTestId('score-error-message')).toHaveTextContent('Error occurred');
    }, {timeout: 2000});
  });
});
