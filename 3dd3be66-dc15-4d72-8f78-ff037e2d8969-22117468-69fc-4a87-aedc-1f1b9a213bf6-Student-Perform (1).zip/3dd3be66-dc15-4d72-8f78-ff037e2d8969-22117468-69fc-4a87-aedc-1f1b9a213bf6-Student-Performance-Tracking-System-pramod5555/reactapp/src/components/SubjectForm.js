import React, { useState } from 'react';
import { API_BASE } from '../apiConfig';

export default function SubjectForm({ onSuccess }) {
    const [name, setName] = useState('');
    const [code, setCode] = useState('');
    const [error, setError] = useState('');
    function handleSubmit(e) { 
    e.preventDefault();
    fetch(`${API_BASE}/api/subjects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, code })
    })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.message || 'Failed to add subject');
            setName('');
            setCode('');
            setError('');
            if (onSuccess) onSuccess();
        })
        .catch(err => setError(err.message));
}
return (
    <form onSubmit={handleSubmit}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Name" required />
        <input value={code} onChange={e => setCode(e.target.value)} placeholder="Code" required />
        <button type="submit">Add Subject</button>
        {error && <div style={{ color: 'red' }}>{error}</div>}
    </form>
);
                                                                                                                                              }
