import React from 'react';
import './Dashboard.css';

export default function Dashboard({ stats }) {
    return (
        < div className="dashboard" >
            <h1>Welcome to School Management</h1>
            <div className="stats-container">
                <div className="stat-card">
                    <h2>{stats.students}</h2>
                    <p>Students</p>
                </div>
                <div className="stat-card">
                    <h2>{stats.scores}</h2>
                    <p>Scores</p>
                </div>
                <div className="stat-card">
                    <h2>{stats.subjects}</h2>
                    <p>Subjects</p>
                </div>
            </div>
        </div >
    );
}
