import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_BASE } from '../apiConfig';

export default function StudentList() { 
const [students, setStudents] = useState([]);
const [gradeFilter, setGradeFilter] = useState('');
const [error, setError] = useState('');
const navigate = useNavigate();

useEffect(() => {
    fetch(`${API_BASE}/api/students`)
        .then(res => {
            if (!res.ok) throw new Error();
            return res.json();
        })
        .then(setStudents)
        .catch(() => setError('API failed'));
}, []);

const filtered = gradeFilter
    ? students.filter(st => st.grade === gradeFilter)
    : students;

if (error) return <div>{error}</div>;
if (!students.length) return <div>No students</div>;

return (
    <section>
        <h3>Student List</h3>
        <input data-testid="grade-filter" value={gradeFilter} placeholder="e.g. 10th" onChange={e => setGradeFilter(e.target.value)} />
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Grade</th><th>Action</th></tr></thead>
            <tbody>
                {filtered.map(st => (
                    <tr key={st.id}>
                        <td>{st.id}</td>
                        <td>{st.name}</td>
                        <td>{st.grade}</td>
                        <td>
                            <button onClick={() => navigate(`/performance/${st.id}`)}>
                                View Performance
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </section>
);
                                                                                                                                                                                                                                                                                                      }
