import React, { useEffect, useState } from 'react';
import { API_BASE } from '../apiConfig';

export default function StudentScores({ studentId }) {
    const [subjects, setSubjects] = useState([]);
    const [scores, setScores] = useState([]);
    const [subjectFilter, setSubjectFilter] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        Promise.all([
            fetch(`${API_BASE}/api/subjects`).then(r => r.json()),
            fetch(`${API_BASE}/api/scores/student/${studentId}`).then(r => r.json())
        ])
            .then(([subs, scrs]) => {
                setSubjects(subs);
                setScores(scrs);
            })
            .catch(() => setError('Not found'));
    }, [studentId]);

    const filtered = subjectFilter
        ? scores.filter(sc => String(sc.subject?.id) === subjectFilter)
        : scores;

    if (error) return <div>{error}</div>;
    if (!scores.length) return <div>No scores found.</div>;

    return (
        <div>
            <h3>Scores</h3>
            <select data-testid="subject-filter" value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)}>
                <option value="">All</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <table>
                <tbody>
                    {filtered.map(sc => (
                        <tr key={sc.id} data-testid={`score-row-${sc.id}`}>
                            <td>{sc.value}</td>
                            <td>{sc.examType}</td>
                            <td>{sc.examDate}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
