import React from 'react';
import { NavLink } from 'react-router-dom';
import './NavigationBar.css';

export default function NavigationBar() {
    return (
        <nav className="nav-bar">
            <div className="logo">
                {/* Replace with your actual logo file */}
                <img src="/logo192.png" alt="School Logo" className="logo-img" />
                <span className="logo-text">School Management</span>
            </div>
            <div className="nav-links">
                <NavLink to="/" end>Dashboard</NavLink>
                <NavLink to="/students">Students</NavLink>
                <NavLink to="/subjects">Subjects</NavLink>
                <NavLink to="/scores">Scores</NavLink>
            </div>
            <div className="profile-icon">
                <img src="/user-icon.png" alt="User Profile" />
            </div>
        </nav>
    );
}
