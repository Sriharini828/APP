import React, { useEffect, useState } from 'react';
import { API_BASE } from '../apiConfig';

export default function SubjectList() {
    const [subjects, setSubjects] = useState([]);
    const [error, setError] = useState('');
    useEffect(() => {
        fetch(`${API_BASE}/api/subjects`)
            .then(res => res.json())
            .then(setSubjects)
            .catch(() => setError('API failed'));
    }, []);

    return (
        <section>
            <h3>Subjects</h3>
            {error && <div style={{ color: 'red' }}>{error}</div>}
            <ul>
                {subjects.map(s => (
                    <li key={s.id}>
                        {s.name} ({s.code})
                    </li>
                ))}
            </ul>
        </section>
    );
}
