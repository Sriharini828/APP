import React, { useState } from 'react';
import { API_BASE } from '../apiConfig';

export default function StudentForm() {
    const [form, setForm] = useState({ name: '', email: '', rollNumber: '', grade: '' });
    const [errors, setErrors] = useState([]);
    const [success, setSuccess] = useState('');

    const validate = () => {
        const errs = [];
        if (!form.name) errs.push('Name must be provided');
        if (!form.email || !form.email.includes('@')) errs.push('Email should be valid');
        if (!form.rollNumber || !/^S\d+$/.test(form.rollNumber)) {
            errs.push('Roll number is required');
        }
        if (!form.grade) errs.push('Grade is required');
        return errs;
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        setSuccess('');
        const errs = validate();
        setErrors(errs);
        if (errs.length) return;
        try {
            const res = await fetch(`${API_BASE}/api/students`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form),
            });
            if (!res.ok) {
                let msg = 'Network error';
                try {
                    const data = await res.json();
                    msg = data.message || msg;
                } catch { }
                setErrors([msg]);
                return;
            }
            setErrors([]);
            setSuccess('Student added successfully');
            setForm({ name: '', email: '', rollNumber: '', grade: '' });
        } catch (err) {
            if (err.response?.data?.message) setErrors([err.response.data.message]);
            else setErrors(['Network error']);
        }
    };

    return (
        <section>
            <h3>Add Student</h3>
            <form onSubmit={handleSubmit}>
                <input data-testid="name-input" name="name" placeholder="Name" value={form.name} onChange={handleChange} />
                <input data-testid="email-input" name="email" type="email" placeholder="Email" value={form.email} onChange={handleChange} />
                <input data-testid="rollNumber-input" name="rollNumber" placeholder="Roll Number" value={form.rollNumber} onChange={handleChange} />
                <input data-testid="grade-input" name="grade" placeholder="Grade" value={form.grade} onChange={handleChange} />
                <button data-testid="submit-button" type="submit" disabled={errors.length > 0}>Add Student</button>
            </form>
            {errors.map((err, idx) => (
                <div key={idx} style={{ color: 'red' }}>{err}</div>
            ))}
            {success && <div style={{ color: 'green' }}>{success}</div>}
        </section>
    );
}
