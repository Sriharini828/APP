import React, { useState, useEffect } from 'react';
import { API_BASE } from '../apiConfig';

export default function ScoreForm() {
    const [students, setStudents] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [form, setForm] = useState({ studentId: '', subjectId: '', value: '', examDate: '', examType: '' });
    const [errors, setErrors] = useState([]);
    const [success, setSuccess] = useState('');

    useEffect(() => {
        fetch(`${API_BASE}/api/students`).then(r => r.json()).then(setStudents);
        fetch(`${API_BASE}/api/subjects`).then(r => r.json()).then(setSubjects);
    }, []);

    const validate = () => {
        const errs = [];
        if (!form.studentId) errs.push('Student is required');
        if (!form.subjectId) errs.push('Subject is required');
        if (form.value === '' || form.value < 0 || form.value > 100) errs.push('Score must be 0-100');
        if (!form.examDate) errs.push('Exam date required');
        if (!form.examType) errs.push('Exam type required');
        return errs;
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        const errs = validate();
        setErrors(errs);
        setSuccess('');
        if (errs.length) return;

        try {
            const res = await fetch(`${API_BASE}/api/scores`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form),
            });
            if (!res.ok) throw new Error();
            setErrors([]);
            setSuccess('Score recorded');
            setForm({ studentId: '', subjectId: '', value: '', examDate: '', examType: '' });
        } catch {
            setErrors(['Error occurred']);
            setSuccess('');
        }
    };

    return (
        <form className="form" onSubmit={handleSubmit}>
            <select data-testid="student-select" name="studentId" value={form.studentId} onChange={handleChange}>
                <option value="">Select Student</option>
                {students.map(s => (<option key={s.id} value={s.id}>{s.name}</option>))}
            </select>
            <select data-testid="subject-select" name="subjectId" value={form.subjectId} onChange={handleChange}>
                <option value="">Select Subject</option>
                {subjects.map(s => (<option key={s.id} value={s.id}>{s.name}</option>))}
            </select>
            <input data-testid="score-value" name="value" type="number" placeholder="Score (0-100)" value={form.value} onChange={handleChange} />
            <input data-testid="exam-date" name="examDate" type="date" value={form.examDate} onChange={handleChange} />
            <select data-testid="exam-type-select" name="examType" value={form.examType} onChange={handleChange}>
                <option value="">Exam Type</option>
                <option value="Quiz">Quiz</option>
                <option value="Final">Final</option>
            </select>
            <button data-testid="submit-score" type="submit" disabled={errors.length > 0}>Record Score</button>
            <div className="form-messages">
                {success && <div data-testid="score-success-message" className="success-text">{success}</div>}
                {errors.length > 0 && (
                    <div data-testid="score-error-message" className="error-text">{errors.map((e, i) => <div key={i}>{e}</div>)}</div>
                )}
            </div>
        </form>
    );
}
