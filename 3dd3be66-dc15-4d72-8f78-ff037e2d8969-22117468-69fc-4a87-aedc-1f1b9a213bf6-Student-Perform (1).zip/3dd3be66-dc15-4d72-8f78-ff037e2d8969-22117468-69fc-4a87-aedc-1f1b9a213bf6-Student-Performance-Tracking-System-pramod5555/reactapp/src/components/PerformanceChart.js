import React, { useEffect, useState } from 'react';
import { API_BASE } from '../apiConfig';

export default function PerformanceChart({ studentId }) {
    const [subjects, setSubjects] = useState([]);
    const [selectedSubject, setSelectedSubject] = useState('');
    const [scores, setScores] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        fetch(`${API_BASE}/api/subjects?studentId=${studentId}`)
            .then(res => res.json())
            .then(setSubjects)
            .catch(() => setSubjects([]));
    }, [studentId]);

    useEffect(() => { 
    if (!selectedSubject) return;
    fetch(`${API_BASE}/api/scores/trend/student/${studentId}/subject/${selectedSubject}`)
        .then(res => res.json())
        .then(data => {
            setScores(data);
            setError('');
        })
        .catch(() => {
            setError('API Err');
            setScores([]);
        });
}, [studentId, selectedSubject]);

return (
    <div className="form-section">
        <h3>Performance Trend</h3>
        <select data-testid="subject-picker" value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>
            <option value="">Select Subject</option>
            {subjects.map((s) => (<option key={s.id} value={s.id}>{s.name}</option>))}
        </select>

        {error && <div data-testid="err-div" className="error-text">{error}</div>}
        {!error && selectedSubject && scores.length === 0 && (
            <div data-testid="nodata-div" className="info-text">No data available</div>
        )}

        {scores.length > 0 && (
            <div className="chart-container">
                <div className="y-axis-labels">
                    <div>100</div>
                    <div>50</div>
                    <div>0</div>
                </div>
                <table>
                    <tbody>
                        {scores.map((sc) => (
                            <tr key={sc.examDate}>
                                <td data-testid={`exam-label-${sc.examDate}`}>{sc.examDate}</td>
                                <td>{sc.value}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
    </div>
);
                                                                                                                                                                                                                                                                                                                                                                                                                        }
