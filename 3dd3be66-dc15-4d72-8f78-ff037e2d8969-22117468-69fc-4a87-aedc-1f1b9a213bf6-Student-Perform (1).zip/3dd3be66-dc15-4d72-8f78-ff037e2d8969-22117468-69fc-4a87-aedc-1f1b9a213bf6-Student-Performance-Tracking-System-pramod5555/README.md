# 3dd3be66-dc15-4d72-8f78-ff037e2d8969-22117468-69fc-4a87-aedc-1f1b9a213bf6
Repository for Teams Project code and project management
